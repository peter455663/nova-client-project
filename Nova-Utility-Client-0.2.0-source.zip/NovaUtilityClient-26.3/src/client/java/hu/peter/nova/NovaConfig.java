package hu.peter.nova;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/** Stores simple client-side display preferences in config/nova.properties. */
public final class NovaConfig {
    private static final Path FILE = FabricLoader.getInstance()
            .getConfigDir().resolve("nova.properties");

    public static boolean showWatermark = true;
    public static boolean showCoordinates = true;
    public static boolean showFps = true;
    public static boolean showDirection = true;
    public static boolean showBiome = true;

    private NovaConfig() {}

    public static void load() {
        if (!Files.exists(FILE)) {
            save();
            return;
        }

        Properties properties = new Properties();
        try (Reader reader = Files.newBufferedReader(FILE)) {
            properties.load(reader);
            showWatermark = Boolean.parseBoolean(properties.getProperty("hud.watermark", "true"));
            showCoordinates = Boolean.parseBoolean(properties.getProperty("hud.coordinates", "true"));
            showFps = Boolean.parseBoolean(properties.getProperty("hud.fps", "true"));
            showDirection = Boolean.parseBoolean(properties.getProperty("hud.direction", "true"));
            showBiome = Boolean.parseBoolean(properties.getProperty("hud.biome", "true"));
        } catch (IOException exception) {
            NovaClient.LOGGER.error("Could not load Nova settings", exception);
        }
    }

    public static void save() {
        Properties properties = new Properties();
        properties.setProperty("hud.watermark", Boolean.toString(showWatermark));
        properties.setProperty("hud.coordinates", Boolean.toString(showCoordinates));
        properties.setProperty("hud.fps", Boolean.toString(showFps));
        properties.setProperty("hud.direction", Boolean.toString(showDirection));
        properties.setProperty("hud.biome", Boolean.toString(showBiome));

        try {
            Files.createDirectories(FILE.getParent());
            try (Writer writer = Files.newBufferedWriter(FILE)) {
                properties.store(writer, "Nova Utility Client settings");
            }
        } catch (IOException exception) {
            NovaClient.LOGGER.error("Could not save Nova settings", exception);
        }
    }
}
