# Nova Utility Client 0.2.0

Client-side Fabric utility/HUD mod for Minecraft Java 26.3.

## Current implemented features
- Right Alt opens the ClickGUI (rebindable in Minecraft Controls).
- Watermark HUD toggle.
- Coordinates HUD toggle.
- FPS HUD toggle.
- Direction HUD toggle.
- Biome HUD toggle.
- Settings saved to `config/nova.properties`.

## Build
Requires Java 25 and Gradle 9.6.0, plus network access to resolve Minecraft/Fabric dependencies.

On Windows, run `build.bat`; the script installs a local JDK and Gradle under `.tools` and builds the mod.
The JAR is produced in `build/libs/`.

This is an early working-scope client-side utility mod, not the full original feature wishlist. It does not implement combat cheats, automated attacks against other players, or server-protection bypasses.
