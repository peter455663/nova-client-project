$ErrorActionPreference = 'Stop'
$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ToolsDir = Join-Path $ProjectDir '.tools'
$JdkArchive = Join-Path $ToolsDir 'temurin-jdk-25.zip'
$JdkExtract = Join-Path $ToolsDir 'jdk-25'
$GradleVersion = '9.6.0'
$GradleHome = Join-Path $ToolsDir "gradle-$GradleVersion"
$GradleArchive = Join-Path $ToolsDir "gradle-$GradleVersion-bin.zip"

try {
    New-Item -ItemType Directory -Force -Path $ToolsDir | Out-Null

    # Download a portable JDK into the project folder; no Windows installation required.
    $ExistingJava = $null
    if (Test-Path $JdkExtract) {
        $ExistingJava = Get-ChildItem -Path $JdkExtract -Filter java.exe -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
    }
    if (-not $ExistingJava) {
        Write-Host 'Downloading portable Eclipse Temurin JDK 25...' -ForegroundColor Cyan
        $JdkUrl = 'https://api.adoptium.net/v3/binary/latest/25/ga/windows/x64/jdk/hotspot/normal/eclipse'
        Invoke-WebRequest -Uri $JdkUrl -OutFile $JdkArchive
        New-Item -ItemType Directory -Force -Path $JdkExtract | Out-Null
        Expand-Archive -Path $JdkArchive -DestinationPath $JdkExtract -Force
        Remove-Item $JdkArchive -Force
        $ExistingJava = Get-ChildItem -Path $JdkExtract -Filter java.exe -Recurse | Select-Object -First 1
    }
    if (-not $ExistingJava) { throw 'Could not find java.exe in the downloaded JDK.' }
    $env:JAVA_HOME = Split-Path (Split-Path $ExistingJava.FullName -Parent) -Parent
    $env:PATH = (Join-Path $env:JAVA_HOME 'bin') + ';' + $env:PATH

    Write-Host 'Using this Java version:' -ForegroundColor Cyan
    & (Join-Path $env:JAVA_HOME 'bin\java.exe') -version

    if (-not (Test-Path (Join-Path $GradleHome 'bin\gradle.bat'))) {
        if (-not (Test-Path $GradleArchive)) {
            Write-Host "Downloading Gradle $GradleVersion..." -ForegroundColor Cyan
            $GradleUrl = "https://services.gradle.org/distributions/gradle-$GradleVersion-bin.zip"
            Invoke-WebRequest -Uri $GradleUrl -OutFile $GradleArchive
        }
        Write-Host 'Extracting Gradle...' -ForegroundColor Cyan
        Expand-Archive -Path $GradleArchive -DestinationPath $ToolsDir -Force
    }

    Push-Location $ProjectDir
    try {
        & (Join-Path $GradleHome 'bin\gradle.bat') --no-daemon build
        if ($LASTEXITCODE -ne 0) { throw "Gradle build failed with exit code $LASTEXITCODE" }
    } finally {
        Pop-Location
    }

    Write-Host ''
    Write-Host 'BUILD SUCCESSFUL! Your mod JAR is in build\libs\' -ForegroundColor Green
    Get-ChildItem (Join-Path $ProjectDir 'build\libs') -Filter '*.jar' | ForEach-Object { Write-Host $_.FullName -ForegroundColor Green }
} catch {
    Write-Host ''
    Write-Host ('BUILD FAILED: ' + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Check your internet connection and send me a screenshot of this window if it fails.' -ForegroundColor Yellow
    exit 1
}
